use anchor_lang::prelude::*;

declare_id!("");

#[program]
pub mod libreria {
    use super::*;

    pub fn agregar_libro(
        ctx: Context<AgregarLibro>,
        titulo: String,
        autor: String,
        año: u32,
    ) -> Result<()> {
        let libro = &mut ctx.accounts.libro;

        libro.titulo = titulo;
        libro.autor = autor;
        libro.año = año;
        libro.usuario = ctx.accounts.usuario.key();

        Ok(())
    }

    pub fn marcar_leido(ctx: Context<MarcarLeido>) -> Result<()> {
        let libro = &mut ctx.accounts.libro;

        libro.leido = true;

        Ok(())
    }

    pub fn eliminar_libro(_ctx: Context<EliminarLibro>) -> Result<()> {
        Ok(())
    }
}

// ---------------------------------------------------------------------
// CONTEXTOS
// ---------------------------------------------------------------------

#[derive(Accounts)]
pub struct AgregarLibro<'info> {
    #[account(
        init,
        payer = usuario,
        space = 8 + 32 + 4 + 200 + 4 + 100 + 4 + 1, // Espacio calculado
        seeds = [b"libro", usuario.key().as_ref()],
        bump
    )]
    pub libro: Account<'info, Libro>,

    #[account(mut)]
    pub usuario: Signer<'info>,

    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct MarcarLeido<'info> {
    #[account(
        mut,
        seeds = [b"libro", usuario.key().as_ref()],
        bump
    )]
    pub libro: Account<'info, Libro>,

    pub usuario: Signer<'info>,
}

#[derive(Accounts)]
pub struct EliminarLibro<'info> {
    #[account(
        mut,
        close = usuario,
        seeds = [b"libro", usuario.key().as_ref()],
        bump
    )]
    pub libro: Account<'info, Libro>,

    #[account(mut)]
    pub usuario: Signer<'info>,
}

// ---------------------------------------------------------------------
// ESTRUCTURA DEL LIBRO
// ---------------------------------------------------------------------

#[account]
pub struct Libro {
    pub usuario: Pubkey,
    pub titulo: String,
    pub autor: String,
    pub año: u32,
    pub leido: bool,
}
