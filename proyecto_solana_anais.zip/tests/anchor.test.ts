import * as anchor from "@project-serum/anchor";
import { Program } from "@project-serum/anchor";
import { Libreria } from "../target/types/libreria";

describe("libreria", () => {
  // Configure the client to use the local cluster.
  anchor.setProvider(anchor.AnchorProvider.env());

  const program = anchor.workspace.Libreria as Program<Libreria>;

  it("Agrega un nuevo libro a la biblioteca!", async () => {
    // Add your test here.
    const user = anchor.getProvider().wallet.publicKey;

    const [libroPubkey] = anchor.web3.PublicKey.findProgramAddressSync(
      [Buffer.from("libro"), user.toBuffer()],
      program.programId
    );

    const tx = await program.methods
      .agregarLibro("Cien años de soledad", "Gabriel García Márquez", 1967)
      .accounts({
        libro: libroPubkey,
        usuario: user,
        systemProgram: anchor.web3.SystemProgram.programId,
      })
      .rpc();

    console.log(" Libro creado!");
    console.log(" Tx signature", tx);
  });
});
