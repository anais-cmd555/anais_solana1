const provider = anchor.AnchorProvider.env();
anchor.setProvider(provider);

const program = anchor.workspace.Libreria; // Asegúrate que coincida el nombre

async function main() {
  console.log("Agregando libro...");

  const user = provider.wallet.publicKey;

  const [libroPubkey] = web3.PublicKey.findProgramAddressSync(
    [Buffer.from("libro"), user.toBuffer()],
    program.programId
  );

  console.log("Enviando transacción...");

  const tx = await program.methods
    .agregarLibro("El Principito", "Antoine de Saint-Exupéry", 1943)
    .accounts({
      libro: libroPubkey,
      usuario: user,
      systemProgram: web3.SystemProgram.programId,
    })
    .rpc();

  console.log(" Libro agregado!");
  console.log(" Transacción:", tx);
}

main();
